﻿using System;

namespace ConsoleApp1
{
    public class PizzaTestDrive
    {
        public static void Main(string[] args)
        {
            PizzaStore nyStore = new NYPizzaStore();
            PizzaStore chicagoStore = new ChicagoPizzaStore();

            Pizza pizza;

            pizza = nyStore.orderPizza("cheese");
            Console.WriteLine("Ethan ordered a " + pizza.getName() + "\n");

            pizza = nyStore.orderPizza("pepperoni");
            Console.WriteLine("Artyom ordered a " + pizza.getName() + "\n");

            pizza = nyStore.orderPizza("veggie");
            Console.WriteLine("Arseniy ordered a " + pizza.getName() + "\n");

            pizza = nyStore.orderPizza("clam");
            Console.WriteLine("Sergey ordered a " + pizza.getName() + "\n");

            pizza = chicagoStore.orderPizza("cheese");
            Console.WriteLine("Artyom ordered a " + pizza.getName() + "\n");

            pizza = chicagoStore.orderPizza("pepperoni");
            Console.WriteLine("Arseniy ordered a " + pizza.getName() + "\n");

            pizza = chicagoStore.orderPizza("veggie");
            Console.WriteLine("Sergey ordered a " + pizza.getName() + "\n");

            pizza = chicagoStore.orderPizza("clam");
            Console.WriteLine("Ethan ordered a " + pizza.getName() + "\n");
        }
    }
}
