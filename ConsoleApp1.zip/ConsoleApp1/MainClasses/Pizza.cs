﻿using java.lang;
using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public abstract class Pizza
    {
        protected string name;

        protected Dough dough;
        protected Sauce sauce;
        protected Veggies[] veggies;
        protected Cheese cheese;
        protected Pepperoni pepperoni;
        protected Clams clam;

        public abstract void prepare();

        public void bake ()
        {
            Console.WriteLine("Bake for 25 minutes at 350");
        }

        public virtual void cut()
        {
            Console.WriteLine("Cutting the pizza into diagonal slices");
        }

        public void box()
        {
            Console.WriteLine("Place pizza in official PizzaStore box");
        }

        public void setName(string name)
        {
            this.name = name;
        }
        public string getName()
        {
            return name;
        }
        public string toString()
        {
            StringBuffer result = new StringBuffer();
            result.append("---- " + name + " ----\n");
            if (dough != null)
            {
                result.append(dough);
                result.append("\n");
            }
            if (sauce != null)
            {
                result.append(sauce);
                result.append("\n");
            }
            if (cheese != null)
            {
                result.append(cheese);
                result.append("\n");
            }
            if (veggies != null)
            {
                for (int i = 0; i < veggies.Length; i++)
                {
                    result.append(veggies[i]);
                    if (i < veggies.Length - 1)
                    {
                        result.append(", ");
                    }
                }
                result.append("\n");
            }
            if (clam != null)
            {
                result.append(clam);
                result.append("\n");
            }
            if (pepperoni != null)
            {
                result.append(pepperoni);
                result.append("\n");
            }
            return result.toString();
        }
    }
}
