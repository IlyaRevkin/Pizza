﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public abstract class PizzaStore 
    {
        public abstract Pizza createPizza(string item);
        internal Pizza orderPizza(string type)
        {
            Pizza pizza = createPizza(type);

            Console.WriteLine("--- Making a " + pizza.getName() + " ---");

            pizza.prepare();
            pizza.bake();
            pizza.cut();
            pizza.box();

            return pizza;
        }
    }
}
