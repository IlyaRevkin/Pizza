﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class PlumTomatoSauce : Sauce
    {
        public string toString()
        {
            return "Tomato sauce with plum tomatoes";
        }
    }
}
