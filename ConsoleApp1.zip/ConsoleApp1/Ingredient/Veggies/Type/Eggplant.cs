﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Eggplant : Veggies
    {
        public string toString()
        {
            return "Eggplant";
        }
    }
}
