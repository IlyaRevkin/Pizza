﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class Spinach : Veggies
    {
        public string toString()
        {
            return "Spinach";
        }
    }
}
