﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class RedPepper : Veggies
    {
        public string toString()
        {
            return "Red Pepper";
        }
    }
}
