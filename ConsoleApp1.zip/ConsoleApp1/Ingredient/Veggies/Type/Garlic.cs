﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class Garlic : Veggies
    {
        public string toString()
        {
            return "Garlic";
        }
    }
}
