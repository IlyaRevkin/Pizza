﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class Mushroom : Veggies
    {
        public string toString()
        {
            return "Mushrooms";
        }
    }
}
