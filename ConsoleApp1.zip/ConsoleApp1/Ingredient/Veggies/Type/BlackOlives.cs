﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    class BlackOlives : Veggies
    {
        public string toString()
        {
            return "Black Olives";
        }
    }
}
