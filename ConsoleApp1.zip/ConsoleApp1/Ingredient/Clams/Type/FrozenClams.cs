﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class FrozenClams : Clams
    {
        public string toString()
        {
            return "Frozen Clams from Chesapeake Bay";
        }
    }
}
