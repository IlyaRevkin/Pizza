﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class FreshClams : Clams
    {
        public string toString()
        {
            return "Fresh Clams from Long Island Sound";
        }
    }
}
