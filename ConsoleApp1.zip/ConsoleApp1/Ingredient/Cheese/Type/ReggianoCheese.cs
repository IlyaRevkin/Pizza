﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class ReggianoCheese : Cheese
    {
        public string toString()
        {
            return "Reggiano Cheese";
        }
    }
}
