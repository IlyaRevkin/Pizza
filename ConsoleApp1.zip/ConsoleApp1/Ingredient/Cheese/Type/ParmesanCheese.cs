﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class ParmesanCheese : Cheese
    {
        public string toString()
        {
            return "Shredded Parmesan";
        }
    }
}
