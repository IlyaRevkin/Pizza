﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class SlicedPepperoni : Pepperoni
    {
        public string toString()
        {
            return "Sliced Pepperoni";
        }
    }
}
