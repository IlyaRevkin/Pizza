﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
	public class ThinCrustDough : Dough
	{
		public string toString()
		{
			return "ThinCrust style extra thick crust dough";
		}
	}
}
