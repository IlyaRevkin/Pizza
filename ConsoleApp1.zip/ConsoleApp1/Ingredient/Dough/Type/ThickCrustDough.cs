﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
	public class ThickCrustDough : Dough
	{
		public string toString()
		{
			return "ThickCrust style extra thick crust dough";
		}
	}
}
